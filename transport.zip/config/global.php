<?php 
//ip de la pc servidor base de datos
define("DB_HOST", "localhost");

// nombre de la base de datos
define("DB_NAME", "proyecto");


//nombre de usuario de base de datos
define("DB_USERNAME", "root");

//conraseña del usuario de base de datos
define("DB_PASSWORD", "sasa");

//codificacion de caracteres
define("DB_ENCODE", "utf8");

//nombre del proyecto
define("proyecto", "2022");
 
 ?>